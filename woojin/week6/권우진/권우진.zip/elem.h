#pragma once
#pragma once
typedef int elem_t;
extern elem_t err_elem;
char* str(elem_t e);