typedef struct a 
{
    int h;
    int w;
} elem_t;

char* str(elem_t e);
extern elem_t err_elem = {-1, -1};
